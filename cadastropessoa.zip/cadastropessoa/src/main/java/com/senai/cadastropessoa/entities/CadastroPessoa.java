package com.senai.cadastropessoa.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "tb_cadastro_pessoa")
public class CadastroPessoa {
	
	//atributos

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long idPessoa;
	
	@Column (name = "nome_pessoa")
	private String nomePessoaAtributo;
	
	@Column (name = "idade")
	private int idadePessoaAtributo;
	
	//construtores
	
	CadastroPessoa(){
	}
	
	CadastroPessoa(Long idPessoaParametro, String nomePessoaParametro, int idadePessoaParametro){
		this.idPessoa = idPessoaParametro;
		this.nomePessoaAtributo = nomePessoaParametro;
		this.idadePessoaAtributo = idadePessoaParametro;
		
	}

	// getters e setters 
	public Long getIdPessoaGetter() {
		return idPessoa;
	}

	public void setIdPessoaSetter(Long idPessoa) {
		this.idPessoa = idPessoa;
	}

	public String getNomePessoaGetter() {
		return nomePessoaAtributo;
	}

	public void setNomePessoaSetter(String nomePessoaAtributo) {
		this.nomePessoaAtributo = nomePessoaAtributo;
	}

	public int getIdadePessoaGetter() {
		return idadePessoaAtributo;
	}

	public void setIdadePessoaSetter(int idadePessoaAtributo) {
		this.idadePessoaAtributo = idadePessoaAtributo;
	}
	
	
	
}
