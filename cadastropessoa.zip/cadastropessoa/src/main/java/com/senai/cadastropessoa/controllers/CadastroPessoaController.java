package com.senai.cadastropessoa.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.senai.cadastropessoa.entities.CadastroPessoa;
import com.senai.cadastropessoa.services.CadastroPessoaService;

@RestController
@RequestMapping("/cadastropessoa")
public class CadastroPessoaController {
	
	@Autowired
	private CadastroPessoaService objetoCadastroPessoaService;
	
	public CadastroPessoa criarNovoCadastroPessoa(CadastroPessoa cadastroPessoaParametro) {
		return objetoCadastroPessoaService.salvarCadastroPessoa(cadastroPessoaParametro); 
		}
	
	@GetMapping
	public List<CadastroPessoa> buscarTodosCadastroPessoa(){
		return objetoCadastroPessoaService.buscarTodosCadastroPessoa();
	}
	
}
